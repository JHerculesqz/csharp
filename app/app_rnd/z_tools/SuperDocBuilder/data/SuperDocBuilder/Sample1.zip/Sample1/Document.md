% 样例
% Monkey
% 2016/2/11

##Why
####Blablabla
![](image/test.jpg)

##What
####micro video
* five minutes
* learn fast
* pragmatism

####geek style
* gentle
* hippy
* passion
* warm
* loser

####garage culture
* offline comunication
* coffee time
* geek responsibility

##How
####Technology
* Front end:Html5,CSS,Javascript
* Back end:Spring,Spring MVC,Mybatis,Hibernate,SOA
* Cloud:MySQL,MongoDB,Hadoop, Storm,Spark

####Video
* Director:Gertie
* Go pro
* After Effect

####We-Media
* open source website
* thrid-party website:youku,youtube
* social app:wechat

##The end